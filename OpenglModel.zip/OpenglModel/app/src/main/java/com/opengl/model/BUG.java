package com.opengl.model;

import android.app.Application;
import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import java.io.Writer;
import java.io.StringWriter;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import android.widget.*;
import java.io.*;

public class BUG extends Application{

	@Override
	public void onCreate()
	{

		super.onCreate();

		Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler(){
				private byte[] bug;
				@Override
				public void uncaughtException(Thread p1, Throwable p2)
				{
					Writer i = new StringWriter();
					p2.printStackTrace(new PrintWriter(i));
					ByteArrayOutputStream baos = new ByteArrayOutputStream();

					p2.printStackTrace(new PrintStream(baos));
					bug = baos.toByteArray();

					try {
						FileOutputStream f=new FileOutputStream(
						"/sdcard/error.log");

						//f.write(i.toString().getBytes());


						f.write(bug);


						f.close();
					} catch (IOException e) {
						e.printStackTrace();
					}


				}
			});
	}


	@Override
	protected void attachBaseContext(Context base) {
		super.attachBaseContext(base);





	}
}

