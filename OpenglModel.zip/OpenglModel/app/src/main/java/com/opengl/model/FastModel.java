package com.opengl.model;

import com.alibaba.fastjson.annotation.JSONField;
import java.util.ArrayList;
import java.util.List;

public class FastModel {

	@JSONField(name = "bones")
	public List<Bones> bones = new ArrayList<>();

	public FastModel setBones(List<Bones> bones) {
		this.bones = bones;
		return this;
	}

	public List<Bones> getBones() {
		return bones;
	}

	@Override
	public String toString() {
		return "Model{"
			+ "bones=" + bones 
			+ "}";
	}

	public static class Bones {

		@JSONField(name = "name")
		public String name;

		@JSONField(name = "pivot")
		public List<Float> pivot = new ArrayList<>();

		@JSONField(name = "cubes")
		public List<Cubes> cubes = new ArrayList<>();

		public Bones setName(String name) {
			this.name = name;
			return this;
		}

		public String getName() {
			return name;
		}

		public Bones setPivot(List<Float> pivot) {
			this.pivot = pivot;
			return this;
		}

		public List<Float> getPivot() {
			return pivot;
		}

		public Bones setCubes(List<Cubes> cubes) {
			this.cubes = cubes;
			return this;
		}

		public List<Cubes> getCubes() {
			return cubes;
		}

		@Override
		public String toString() {
			return "Bones{"
				+ "name=" + name
				+ ", pivot=" + pivot
				+ ", cubes=" + cubes 
				+ "}";
		}

		public static class Cubes {

			@JSONField(name = "origin")
			public List<Float> origin = new ArrayList<>();

			@JSONField(name = "size")
			public List<Integer> size = new ArrayList<>();

			@JSONField(name = "uv")
			public List<Integer> uv = new ArrayList<>();

			public Cubes setOrigin(List<Float> origin) {
				this.origin = origin;
				return this;
			}

			public List<Float> getOrigin() {
				return origin;
			}

			public Cubes setSize(List<Integer> size) {
				this.size = size;
				return this;
			}

			public List<Integer> getSize() {
				return size;
			}

			public Cubes setUv(List<Integer> uv) {
				this.uv = uv;
				return this;
			}

			public List<Integer> getUv() {
				return uv;
			}

			@Override
			public String toString() {
				return "Cubes{"
					+ "origin=" + origin
					+ ", size=" + size
					+ ", uv=" + uv 
					+ "}";
			}

		}

	}

}
