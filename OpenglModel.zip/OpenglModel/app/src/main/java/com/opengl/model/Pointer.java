package com.opengl.model;

public class Pointer {
	
    public float x;
	
    public float y;
	
	public float z;
	
    public void set(float x, float y) {
		
		this.x = x;
		
		this.y = y;
	}

    public Pointer() {}

    public Pointer(float x,float z, float y) {
		
		this.x = x;
		
		this.y = y;
		
		this.z = z;
	}


	
}

