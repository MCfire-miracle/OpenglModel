package com.opengl.model;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLSurfaceView;
import android.widget.Button;
import android.os.Bundle;
import android.view.View;
import android.view.MotionEvent;
import android.graphics.PixelFormat;



public class MainActivity extends Activity
{
	private float anglex = 0f;
	private float angley = 0f;
	private ModelRender myRender;
	private GLSurfaceView glView;
	private Button button;

	

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		button = (Button)this.findViewById(R.id.mainButton1);
	    glView = (GLSurfaceView)this.findViewById(R.id.main_surface);
		glView.setOnTouchListener(new GLSurfaceView.OnTouchListener(){

				private float downx;
				private float downy;
				private float my;
				private float mx;

				@Override
				public boolean onTouch(View p1, MotionEvent event)
				{
				
					switch(event.getActionMasked()){
						case event.ACTION_DOWN:
							downx = event.getRawX();
							downy = event.getRawY();
							mx = anglex;
							my = angley;
							break;
						case event.ACTION_MOVE:
							anglex =mx+ (event.getRawX()-downx);
							angley =my+ (event.getRawY()-downy);
							
							myRender.setmove(anglex,angley);
							break;
						case event.ACTION_UP:
						
							break;
					}
					
					
					
					return true;
				}
			});
		button.setOnClickListener(new Button.OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					myRender.thread();
					
				}
		});
		start(glView,"2b1fad0afef0b8bb");
		
	}
	
	
	public void start(GLSurfaceView v,String name){
		Bitmap bitmap = //BitmapFactory.decodeResource(context.getResources(), R.drawable.ic_launcher);
			Rocker.getImageFromAssetsFile(this,
			//"creeper"
			//"chicken"
			//"steve"
			//"d0926b0b22d951f8"
			//"215443b94bd22715"
			//"dummy"
			name
			);
		
			
		myRender = new ModelRender(this);
		myRender.setBitmap(bitmap,glView);
		
		v.setZOrderOnTop( true );
		v.setEGLConfigChooser( 8, 8, 8, 8, 16, 0 );
		v.getHolder().setFormat( PixelFormat.TRANSLUCENT);//.RGBA_8888 );//可以在网上找一找设置Render背景透明的方法(大屏预览透明背景需要设置activity背景透明)
		v.setRenderer(myRender);
	}
	
	
	
    
}



