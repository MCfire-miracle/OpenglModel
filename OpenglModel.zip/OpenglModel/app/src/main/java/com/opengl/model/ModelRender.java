package com.opengl.model;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLSurfaceView;
import android.opengl.GLSurfaceView.Renderer;
import android.opengl.GLU;
import android.opengl.GLUtils;
import android.os.Bundle;
import android.view.MotionEvent;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import java.util.List;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.BufferedReader;
import android.graphics.PixelFormat;
import com.alibaba.fastjson.JSON;
import android.widget.Toast;
import android.view.View;
import android.content.res.AssetManager;
import java.io.IOException;
import android.widget.*;
import com.opengl.model.MainActivity.*;
import android.util.*;
import com.opengl.model.FastModel;
import com.opengl.model.FastModel.*;
import com.opengl.model.FastModel.Bones.*;
import java.util.*;
import android.os.*;

public class ModelRender implements GLSurfaceView.Renderer{

	public static final float REFRESHTIME = 10;
	private byte[] cubeFacets = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,
		13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29,
		30, 31, 32, 33, 34, 35, };


	private Context context;

	private int texture;

	private FastModel model;

	private ByteBuffer cubeFacetsBuffer;

	private Integer degree = 0;
	
	
	private boolean THREADSTOP = true;
	private Bitmap bitmap;

	private Map<String,float[]> degrees =new HashMap<String,float[]>() ;
	
	private float angley;
	private float anglex;

	private GLSurfaceView glView;

	private GL10 supergl;

	public ModelRender(Context main){
		this.context = main;
		
		cubeFacetsBuffer = bufferUtil(cubeFacets);

		
	}

	public void setBitmap(Bitmap bitmap,GLSurfaceView v)
	{
		if((bitmap.getWidth()!=64)||(bitmap.getHeight()!=64))return;
		int color = bitmap.getPixel(50, 16);//uv点
		this.bitmap = bitmap;
		glView = v;
		if(color == 0)
			model = JSON.parseObject(Rocker.getJsonFromAssets(context,"alex"), FastModel.class);
		else
			model = JSON.parseObject(Rocker.getJsonFromAssets(context,"steve"), FastModel.class);
			
		//加载其他模型需要 调整model 重载
			
		//此处不能请求glview刷新
	}
	
	
	
	
	public void thread(){
		if(THREADSTOP == false){
			THREADSTOP = true;
			return;
		}
		THREADSTOP = false;

		new Thread(){
			@Override
			public void run(){

				long mtime = System.currentTimeMillis();
				time:for (int i=0;i < 1;)
				{
					if(THREADSTOP)break time;
					if((System.currentTimeMillis()-mtime) > REFRESHTIME){
						if(degree == 360)
							degree = 0;

						float mdegree = (float)(30 * Math.sin(degree*(Math.PI/180f)));
						mtime = System.currentTimeMillis();
						Message m = new Message();
						m.what = 0;
						m.arg1 = (int)( mdegree*100);
						handler.sendMessage(m);
						degree += 1;

					}
				}
			}
		}.start();
	}
	public Handler handler = new Handler(){

		@Override
		public void handleMessage(Message msg){
			super.handleMessage(msg);
			switch(msg.what){
				case 0:
					effect((msg.arg1/-100f),(msg.arg1/100f));
					//myRender.effect(event.getX(),event.getY());
					glView.requestRender();

					break;

			}


		}
	};
	public void setmove(float a,float b){
		anglex = a;
		angley = b;
	}
	
	public IntBuffer bufferUtil(int[] arr){
		IntBuffer buffer;
		ByteBuffer byteBuffer = ByteBuffer.allocateDirect(arr.length * 4);
		byteBuffer.order(ByteOrder.nativeOrder());
		buffer = byteBuffer.asIntBuffer();
		buffer.put(arr);
		buffer.position(0);
		return buffer;
	}
	public ByteBuffer bufferUtil(byte[] arr){
		ByteBuffer byteBuffer = ByteBuffer.allocateDirect(arr.length);
		byteBuffer.order(ByteOrder.nativeOrder());
		byteBuffer.put(arr);
		byteBuffer.position(0);
		return byteBuffer;
	}
	public FloatBuffer bufferUtil(float[] arr){
		FloatBuffer buffer;
		ByteBuffer byteBuffer = ByteBuffer.allocateDirect(arr.length * 4);
		byteBuffer.order(ByteOrder.nativeOrder());
		buffer = byteBuffer.asFloatBuffer();
		buffer.put(arr);
		buffer.position(0);
		return buffer;
	}

	@Override
	public void onSurfaceCreated(GL10 gl, EGLConfig config) {
		// 关闭抗抖动
		gl.glDisable(GL10.GL_DITHER);
		// 设置系统对透视进行修正
		gl.glHint(GL10.GL_PERSPECTIVE_CORRECTION_HINT, GL10.GL_FASTEST);
		gl.glClearColor(0.3f,0.3f,0.3f,0.9f);
		// 设置阴影平滑模式
		gl.glShadeModel(GL10.GL_SMOOTH);
		// 启用深度测试
		gl.glEnable(GL10.GL_DEPTH_TEST);
		// 设置深度测试的类型
		gl.glDepthFunc(GL10.GL_LEQUAL);

		// 启用2D纹理贴图
		gl.glEnable(GL10.GL_TEXTURE_2D);
		// 装载纹理

		gl.glBlendFunc(GL10.GL_SRC_ALPHA, GL10.GL_ONE_MINUS_SRC_ALPHA);
		gl.glEnable(GL10.GL_BLEND);

		loadTexture(gl);
		supergl = gl;
	}
	@Override
	public void onSurfaceChanged(GL10 gl, int width, int height) {
		// 设置3D视窗的大小及位置
		gl.glViewport(0, 0, width, height);
		// 将当前矩阵模式设为投影矩阵
		gl.glMatrixMode(GL10.GL_PROJECTION);
		// 初始化单位矩阵
		gl.glLoadIdentity();
		// 计算透视视窗的宽度、高度比
		float ratio = (float) width / height;
		// 调用此方法设置透视视窗的空间大小。
		gl.glFrustumf(-ratio, ratio, -1, 1, 1, 10);
	}


	@Override
	public void onDrawFrame(GL10 gl) {
		
		// 清除屏幕缓存和深度缓存
		gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
		// 启用顶点座标数据
		gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
		// 启用贴图座标数组数据
		gl.glEnableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
		// 设置当前矩阵模式为模型视图。
		gl.glMatrixMode(GL10.GL_MODELVIEW);

		//running
		gl.glLoadIdentity();
		/*
		 GLU.gluLookAt(gl,
		 .0f, 0.1f, 0.5f,
		 0.0f, 0.0f, 0.0f,
		 0.0f, 0.8f, 0.0f);*/

		gl.glTranslatef(0f, 0.0f, -3.0f);
		// 旋转图形
		gl.glRotatef(angley, 1, 0, 0);
		gl.glRotatef(anglex, 0, 1, 0);

		DrawFrameStart(gl,model);
		// 绘制结束
		gl.glFinish();
		// 禁用顶点、纹理座标数组
		gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glDisableClientState(GL10.GL_TEXTURE_COORD_ARRAY);



	}
	//
	public void effect(float a,float b){
		float[] data0 = degrees.get("rightArm");
		if(data0 == null)return;
		//data0[0] = a;
		data0[1] = a;
		float[] data1 = degrees.get("rightSleeve");
		if(data1 == null)return;
		//data1[0] = a;
		data1[1] = a;
		float[] data2 = degrees.get("leftArm");
		if(data2 == null)return;
		//data2[0] = a;
		data2[1] = b;
		float[] data3 = degrees.get("leftSleeve");
		if(data3 == null)return;
		//data3[0] = a;
		data3[1] = b;

		float[] data4 = degrees.get("rightLeg");
		if(data4 == null)return;
		//data0[0] = a;
		data4[1] = b;
		float[] data5 = degrees.get("rightPants");
		if(data5 == null)return;
		//data1[0] = a;
		data5[1] = b;
		float[] data6 = degrees.get("leftLeg");
		if(data6 == null)return;
		//data2[0] = a;
		data6[1] = a;
		float[] data7 = degrees.get("leftPants");
		if(data7 == null)return;
		//data3[0] = a;
		data7[1] = a;

	}

	private void DrawFrameStart(GL10 gl, FastModel model)
	{
		if(model.getBones()==null)return;
		List<FastModel.Bones> boneslist = model.getBones();

		start:for (int i=0;i < boneslist.size();i++)
		{
			//第一层
			Bones bones = boneslist.get(i);
			List<Float> pivot = bones.getPivot();
			//List<Float> angle = bones.getAngle();
			String name = bones.getName();
			if(degrees.get(name)==null)
				degrees.put(name,new float[]{0,0});

			List<FastModel.Bones.Cubes> cubeslist = bones.getCubes();
			if (cubeslist.size() == 0)continue start;
			starts:for (int i1=0;i1 < cubeslist.size();i1++)
			{
				//第二层
				Cubes cubes = cubeslist.get(i1);
				if (cubes == null)
					continue starts;
				float cut = 0;
				if((name.equals("hat") ||name.equals("leftPants") ||name.equals("rightPants") ||name.equals("rightSleeve") || (name.equals("jacket") || name.equals("leftSleeve")))){
					cut = 0.8f;
					//continue start2;
				}
				List<Float> origin = cubes.getOrigin();
				List<Integer> size = cubes.getSize();
				//List<Integer> uvsize = cubes.getUvsize();
				List<Integer> uv = cubes.getUv();

				FloatBuffer VerticesBuffer = bufferUtil(
					Rocker.BuildModel(
						new Pointer(
							(origin.get(0)-cut/2f)*10,
							(origin.get(1)+cut/2f)*10,
							(origin.get(2)-cut/2f)*10),
						(size.get(0)+ cut)*10,
						(size.get(2)+ cut)*10,
						(size.get(1)+ cut)*10,

						new Pointer(
							pivot.get(0)*10,
							pivot.get(1)*10,
							pivot.get(2)*10),


						degrees.get(name)[0],
						degrees.get(name)[1]));

				FloatBuffer TexturesBuffer = bufferUtil(
					//( name.equals("rightArm") || (name.equals("rightPants") || name.equals("rightLeg") )?
					//Rocker.BuildTexturer(uv.get(0),uv.get(1),uvsize.get(0),uvsize.get(2),uvsize.get(1))
					//:
					Rocker.BuildTexturel(
						uv.get(0),
						uv.get(1),
						size.get(0),
						size.get(2),
						size.get(1))
				//)
				);

				DrawFrameCube(gl,VerticesBuffer,TexturesBuffer);

			}

		}






		/*
		 for (int i=0;i < bones.size();i++)
		 {
		 Bones cube = bones.get(i);
		 List<Float> pivot = cube.getPivot();
		 List<Float> origin = cube.getCubes().get(0).getOrigin();
		 List<Integer> size = cube.getCubes().get(0).getSize();
		 List<Integer> uvsize = cube.getCubes().get(0).getUvsize();
		 List<Integer> uv = cube.getCubes().get(0).getUv();
		 List<Float> angle = cube.getAngle();
		 String name = cube.getName();
		 }*/
	}

	private void DrawFrameCube(GL10 gl,FloatBuffer VerticesBuffer,FloatBuffer TexturesBuffer){

		gl.glVertexPointer(3, GL10.GL_FLOAT, 0, VerticesBuffer);//cubeVerticesBuffer);
		// 设置贴图的的座标数据
		gl.glTexCoordPointer(2, GL10.GL_FLOAT, 0, TexturesBuffer);//cubeTexturesBuffer);
		// 执行纹理贴图
		gl.glBindTexture(GL10.GL_TEXTURE_2D, texture);
		// 按cubeFacetsBuffer指定的面绘制三角形
		gl.glDrawElements(GL10.GL_TRIANGLES, cubeFacetsBuffer.remaining(),
						  GL10.GL_UNSIGNED_BYTE, cubeFacetsBuffer);

	}

	private void loadTexture(GL10 gl)
	{
		//Bitmap bitmap = null;
		try
		{
			//bitmap = this.bitmap; 
			//BitmapFactory.decodeResource(context.getResources(), R.drawable.ic_launcher);
			//BitmapFactory.decodeFile("/sdcard/d27d24703fc2b765.png");
			//bitmap.getPixel();
			int[] textures = new int[1];
			// 指定生成N个纹理（第一个参数指定生成1个纹理），
			// textures数组将负责存储所有纹理的代号。
			gl.glGenTextures(1, textures, 0);
			// 获取textures纹理数组中的第一个纹理
			texture = textures[0];
			// 通知OpenGL将texture纹理绑定到GL10.GL_TEXTURE_2D目标中
			gl.glBindTexture(GL10.GL_TEXTURE_2D, texture);
			// 设置纹理被缩小（距离视点很远时被缩小）时候的滤波方式
			gl.glTexParameterf(GL10.GL_TEXTURE_2D,
							   GL10.GL_TEXTURE_MIN_FILTER, GL10.GL_NEAREST);//GL_NEAREST);
			// 设置纹理被放大（距离视点很近时被方法）时候的滤波方式
			gl.glTexParameterf(GL10.GL_TEXTURE_2D,
							   GL10.GL_TEXTURE_MAG_FILTER, GL10.GL_NEAREST);
			// 设置在横向、纵向上都是平铺纹理
			gl.glTexParameterf(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_WRAP_S,
							   GL10.GL_REPEAT);
			gl.glTexParameterf(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_WRAP_T,
							   GL10.GL_REPEAT);
			// 加载位图生成纹理
			GLUtils.texImage2D(GL10.GL_TEXTURE_2D, 0, bitmap, 0);      
		}
		finally
		{
			// 生成纹理之后，回收位图
			if (bitmap != null)
				bitmap.recycle();
		}
	}

	
}
	
  
 
  
