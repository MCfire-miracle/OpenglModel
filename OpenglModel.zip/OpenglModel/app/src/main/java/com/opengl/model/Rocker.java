package com.opengl.model;
import android.graphics.*;
import android.content.*;
import android.content.res.*;
import java.io.*;

public class Rocker
{

	/*[error]
	       z+
	       |
		   |
		   |
		   |
		   |__________x+
		  /
	     /
		/
	   /
	  y+

	*/
	
	public static Pointer build(
		Pointer source
		, Pointer target
		, float degree,float degree1){
		//x2+y2=p2
		//(0,0);(1,1);
		//x z 为坐标 x正方向旋转
		float len_a = (target.x - source.x);
		float len_b = (target.z - source.z) ;
		//float leny = target.y - source.y ;
		double p = Math.sqrt(Math.pow(len_a,2)+ Math.pow(len_b,2));
		//double p1 = Math.sqrt(Math.pow(leny,2)+ Math.pow(lenz,2));
		//double p3 = Math.sqrt(Math.pow(lenx,2)+ Math.pow(leny,2));
		float angle = (float) getdegrees(p,len_a,len_b)+degree;
		//float angle2 = (float) getdegrees(p,leny,lenz);
		//float angle3 = (float) getdegrees(p,lenx,leny);

		Pointer target1 = new Pointer((float)getcosa(p, angle), (float)getsina(p, angle)+source.z, target.y);

		float len_c = (target1.y - source.y) ;
		float len_d = (target1.z - source.z) ;

		double p1 = Math.sqrt(Math.pow(len_c, 2) + Math.pow(len_d, 2));

		float angle1 = (float) getdegrees(p1, len_c, len_d) + degree1;
		//0 1  -1 1 90 -1 2
		
		return new Pointer((target1.x+source.x )/ 100f,( (float)getsina(p1, angle1)+source.z)/100f, ((float)getcosa(p1, angle1)+source.y)/100);

	}
	public static float[] BuildTexturel(int mX, int mY, int mL, int mW, int mH) {

		float TB1 = mW + mX;//1+2[a]+3+4[b]
		float TB2 = mW + mX + mL;//12[b]+[c]34


		float B1 = mW + mX + mL + mW;//
		float B2 = mW + mX + mL + mW + mL;//


		float T1 = mW + mX + mL + mL;//


		float H1 = mW + mY;//
		float H2 = mW + mY + mH;//

		return new float[]
		{//F
			B2 / 64f, H2 / 64f, B2 / 64f, H1 / 64f, B1 / 64f, H1 / 64f
			, B1 / 64f, H1 / 64f, B1 / 64f, H2 / 64f, B2 / 64f, H2 / 64f
			//D
			, TB1 / 64f, H2 / 64f, TB2 / 64f, H2 / 64f, TB2 / 64f, H1 / 64f
			, TB2 / 64f, H1 / 64f, TB1 / 64f, H1 / 64f, TB1 / 64f, H2 / 64f
			//B
			, TB2 / 64f, mY / 64f, T1 / 64f, mY / 64f, T1 / 64f, H1 / 64f
			, T1 / 64f, H1 / 64f, TB2 / 64f, H1 / 64f, TB2 / 64f, mY / 64f
			//E
			, B1 / 64f, H2 / 64f, B1 / 64f, H1 / 64f, TB2 / 64f, H1 / 64f
			, TB2 / 64f, H1 / 64f, TB2 / 64f, H2 / 64f, B1 / 64f, H2 / 64f
			//A
			, TB2 / 64f, mY / 64f, TB1 / 64f, mY / 64f, TB1 / 64f, H1 / 64f
			, TB1 / 64f, H1 / 64f, TB2 / 64f, H1 / 64f, TB2 / 64f, mY / 64f
			//C
			,  mX / 64f, H1 / 64f,  mX / 64f, H2 / 64f, TB1 / 64f, H2 / 64f
			, TB1 / 64f, H2 / 64f, TB1 / 64f, H1 / 64f,  mX / 64f, H1 / 64f};

	}
	

/*

uv 

    [tb1] [tb2] [t1]
      a--L--b--L--c      [1]
      |    /|\    |
	  w  A  w  B  w
	  |/    |    \|
	  a--L--b--L--c      [2]
  a-W-b--L--c-W-d--L--e  [3] 
  |\  |    /|\  |\    |
  h C h  D  h E h  F  h
  |  \|/    |  \|    \|
  a-W-b--L--c-W-d--L--e  [4]

[mx][tb1] [tb2][b1]  [b2]

	 return new float[]
	 {//F
	 B2 / 64f, H2 / 64f, B2 / 64f, H1 / 64f, B1 / 64f, H1 / 64f
	 , B1 / 64f, H1 / 64f, B1 / 64f, H2 / 64f, B2 / 64f, H2 / 64f
	 //D
	 , TB1 / 64f, H2 / 64f, TB2 / 64f, H2 / 64f, TB2 / 64f, H1 / 64f
	 , TB2 / 64f, H1 / 64f, TB1 / 64f, H1 / 64f, TB1 / 64f, H2 / 64f
	 //B
	 , TB2 / 64f, mY / 64f, T1 / 64f, mY / 64f, T1 / 64f, H1 / 64f
	 , T1 / 64f, H1 / 64f, TB2 / 64f, H1 / 64f, TB2 / 64f, mY / 64f
	 //E
	 , B1 / 64f, H2 / 64f, B1 / 64f, H1 / 64f, TB2 / 64f, H1 / 64f
	 , TB2 / 64f, H1 / 64f, TB2 / 64f, H2 / 64f, B1 / 64f, H2 / 64f
	 //A
	 , TB2 / 64f, mY / 64f, TB1 / 64f, mY / 64f, TB1 / 64f, H1 / 64f
	 , TB1 / 64f, H1 / 64f, TB2 / 64f, H1 / 64f, TB2 / 64f, mY / 64f
	 //C
	 ,  mX / 64f, H1 / 64f,  mX / 64f, H2 / 64f, TB1 / 64f, H2 / 64f
	 , TB1 / 64f, H2 / 64f, TB1 / 64f, H1 / 64f,  mX / 64f, H1 / 64f};
	 

*/

	
	
	public static double getdegrees(double p,float lena,float lenb){
		if(lena >= 0 && lenb >=0)
			return Math.toDegrees(Math.acos(lena/p));
			
		else if(lena < 0 && lenb >= 0)
			return Math.toDegrees(Math.acos(lenb/p)+Math.PI/2);
			
		else if(lena < 0 && lenb < 0)
			return Math.toDegrees(Math.acos(Math.abs(lena)/p)+Math.PI);
			
		else if(lena >= 0 && lenb < 0)
			return Math.toDegrees(Math.acos(Math.abs(lenb)/p)+Math.PI*3/2);
			
		else 
			return 0;
	}
	public static float[] BuildModel(
		Pointer model
		, float mLength, float mWidth, float mHeight
		, Pointer source
		, float degree,float off) {

		float mX = model.x;
		float mZ = model.z;
		float mY = model.y;
		float mX2 = mX + mLength;
		float mZ2 = mZ - mHeight;
		float mY2 = mY + mWidth;
		//x-y-z-x2-y2-z2
		//     |z[1]   [2]
		//     |[3]   [4]
		//     |_[1*]__x[2*]
		//    /y[3*]   [4*]
		
		Pointer t1 = build(source,new Pointer(mX,mZ,mY),degree,off);
		Pointer t2 = build(source,new Pointer(mX2,mZ,mY),degree,off);
		Pointer t3 = build(source,new Pointer(mX,mZ,mY2),degree,off);
		Pointer t4 = build(source,new Pointer(mX2,mZ,mY2),degree,off);
		
		Pointer b1 = build(source,new Pointer(mX,mZ2,mY),degree,off);
		Pointer b2 = build(source,new Pointer(mX2,mZ2,mY),degree,off);
		Pointer b3 = build(source,new Pointer(mX,mZ2,mY2),degree,off);
		Pointer b4 = build(source,new Pointer(mX2,mZ2,mY2),degree,off);
		
		return new float[]
		{
			b1.x,b1.z,b1.y//1*mX, mZ2, mY//1*
			, t1.x,t1.z,t1.y//1, mX, mZ, mY//1
			, t2.x,t2.z,t2.y//2, mX2, mZ, mY//2

			, t2.x,t2.z,t2.y//2, mX2, mZ, mY//2
			, b2.x,b2.z,b2.y//2*, mX2, mZ2, mY//2*
			, b1.x,b1.z,b1.y//1*, mX, mZ2, mY//1*

			, b3.x,b3.z,b3.y//3*, mX, mZ2, mY2//3*
			, b4.x,b4.z,b4.y//4*, mX2, mZ2, mY2//4*
			, t4.x,t4.z,t4.y//4, mX2, mZ, mY2//4

			, t4.x,t4.z,t4.y//4, mX2, mZ, mY2//4
			, t3.x,t3.z,t3.y//3, mX, mZ, mY2//3
			, b3.x,b3.z,b3.y//3*, mX, mZ2, mY2//3*

			, b1.x,b1.z,b1.y//1*, mX, mZ2, mY//1*
			, b2.x,b2.z,b2.y//2*, mX2, mZ2, mY//2*
			, b4.x,b4.z,b4.y//4*, mX2, mZ2, mY2//4*

			, b4.x,b4.z,b4.y//4*, mX2, mZ2, mY2//4*
			, b3.x,b3.z,b3.y//3*, mX, mZ2, mY2//3*
			, b1.x,b1.z,b1.y//1*, mX, mZ2, mY//1*

			, b2.x,b2.z,b2.y//2*, mX2, mZ2, mY//2*
			, t2.x,t2.z,t2.y//2, mX2, mZ, mY//2
			, t4.x,t4.z,t4.y//4, mX2, mZ, mY2//4

			, t4.x,t4.z,t4.y//4, mX2, mZ, mY2//4
			, b4.x,b4.z,b4.y//4*, mX2, mZ2, mY2//4*
			, b2.x,b2.z,b2.y//2*, mX2, mZ2, mY//2*

			, t2.x,t2.z,t2.y//2, mX2, mZ, mY//2
			, t1.x,t1.z,t1.y//1, mX, mZ, mY//1
			, t3.x,t3.z,t3.y//3, mX, mZ, mY2//3

			, t3.x,t3.z,t3.y//3, mX, mZ, mY2//3
			, t4.x,t4.z,t4.y//4, mX2, mZ, mY2//4
			, t2.x,t2.z,t2.y//2, mX2, mZ, mY//2

			, t1.x,t1.z,t1.y//1, mX, mZ, mY//1
			, b1.x,b1.z,b1.y//1*, mX, mZ2, mY//1*
			, b3.x,b3.z,b3.y//3*, mX, mZ2, mY2//3*

			, b3.x,b3.z,b3.y//3*, mX, mZ2, mY2//3*
			, t3.x,t3.z,t3.y//3, mX, mZ, mY2//3
			, t1.x,t1.z,t1.y//1, mX, mZ, mY//1
			
			
			};

	}
	
	
	public static double getcosa(double p,double degree){

		return (Math.rint(p*Math.cos(Math.toRadians(degree))));
	}
	public static double getsina(double p,double degree){
		
		return (Math.rint(p*Math.sin(Math.toRadians(degree))));
	}
	public static Bitmap getImageFromAssetsFile(Context context, String fileName ) {
        Bitmap image = null;
        AssetManager am = context.getResources().getAssets();
        try {
            InputStream is = am.open(fileName+".png");
            image = BitmapFactory.decodeStream(is);
            is.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return image;
	}
	public static String getJsonFromAssets(Context context,String fileName){
		try {
			InputStreamReader inputReader = new InputStreamReader(context.getResources().getAssets().open(fileName+".json"));
			BufferedReader bufReader = new BufferedReader(inputReader);
			String line="";
			String Result="";
			while((line = bufReader.readLine()) != null)
				Result += line;
			return Result;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "{}";
	}
}

	 
